import json
import boto3
import logging
import os
from operator import itemgetter
from utils import json_response


region = os.environ['AWS_REGION']
client = boto3.client('greengrassv2', region_name=region)
logging.getLogger().setLevel(logging.INFO)
logging.info('Loading  get core device details lambda function')


def post(event, context):
    try:
        body = json.loads(event['body'])
        if 'device_name' in body.keys():
            installed_components = client.list_installed_components(
                coreDeviceThingName=body['device_name']
            )
            data = {
                'installed_components': installed_components['installedComponents']
            }
        else:
            data = "wrong body"
        logging.info(data)
        return {
            'statusCode': 200,
            'body': json.dumps(data, default=str),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
        }
    except Exception as e:
        logging.error(e)
        return {
            'statusCode': 404,
            'body': json.dumps(e),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
        }
